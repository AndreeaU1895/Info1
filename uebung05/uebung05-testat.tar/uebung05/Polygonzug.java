import java.util.Arrays;	// import um zu ermoeglichen umwandulg von char zu array

public class Polygonzug{
   public static void main(String[] args){

	//Anzahl der Zeichen einlesen
	 int length = StdIn.readInt();

	//eine Zeichenfolge einlesen, in chararray umwandeln und speichern
	char [] kette = StdIn.readString().toCharArray();
	
	StdOut.println(Arrays.toString(kette));  // umgewandelte Zeichenfolge ausgeben

	int x1 = 0, y1 = 0, x2 = 0, y2 = 0;		// startwerte der punkte x1,y1 und x2,y2. Bei 1 handelt es sich um Ursprungskoordinate und 2 Endkoordinate einer Linie

	String[] richtung = {"oben", "rechts", "unten", "links"}; //richtungen eingeben. das ist nur zur veranschaulichkeit und bessere übersicht gedacht
	int pos = 1; // startrichtung fixieren, pos 1 ist rechts (im array) - richtung positive  x-Achse orientiert 
	int[] scale = calculateScale(kette);  // große des Fensters mit Hilfe der Funktion calculate Fenster berechnen und im array "scale" speichern
	StdDraw.setXscale( scale[0] - 1, scale[1] + 1); //x1 und x2. größe des Fensters festlegen, hierbei um ein cm größere Feld als Zeichnung selbst machen
	StdDraw.setYscale( scale[2] - 1, scale[3] + 1); // y1 und y2


	for(int i = 0; i< length; i++){   // Zeichenkette aus array "kette" verarbeiten und einen dragon zeichnen

	   if (kette[i] == 'R'){  		// bei dem Zeichen R aus dem array "kette" wird die richtung um 90 Grad nach rechts gedreht.

		pos = pos == 3 ? 0 : pos + 1;  // da der array nur Länge 4 hat (also 4 Richtungen), wird bei der letzter "Richtung" auf die erste gesprungen. ansonsten + 1

	   } else if (kette[i] == 'L'){  // bei dem Zeichen L aus dem array "kette" wird die richtung um 90 Grad nach links gedreht.

		pos = pos == 0 ?  3 : pos - 1; // da der array nur Länge 4 hat (also 4 Richtungen), wird bei der erster "Richtung" auf die letzte gesprungen. ansonsten - 1
	   } 
	   	else { 						// bei dem Zeichen F aus dem array "kette" wird eine Linie gezeichnet und Koordinaten aktualisiert

		if( richtung[pos].equals("oben")){   //  wenn aktuelle Richtung nach oben zeigt, zeichne eine Linie nach oben
		
		  y2++;								// Die nächste Koordinate um 1 vergrößern (in positive Richtung) . 
		  StdDraw.line(x1, y1, x2 , y2 );  // Gerade zeichnen 

		 } else if(richtung[pos].equals("rechts")){ // vergleich zwischen String
		 
			x2++;
		  	StdDraw.line(x1, y1, x2, y2); 

		 } else if ( richtung[pos].equals("unten")){ 
		 
			y2--;
		  	StdDraw.line(x1, y1, x2, y2 ); 

		 } else {
		 
			x2--;
			StdDraw.line(x1, y1, x2, y2);
		   
		 }
		 x1 = x2;		// End-Koordinate (x2; y2) wird zur Start-Koordinate (x1; y1) beim nächstem Ablauf der Schleife
		 y1 = y2;
	  }

	}
       }

	/**
	*	die Funktion berechnet die größe der Zeichnung. Also wie weit nach rechts/links/oben/unten gezeichnet wird
	*	private da Funktion nur innerhalb der Klasse benutzt werden soll.
	*	Statisch weil es kein Objekt erzeugt wird und die Funktion aus main Funktion ausgerufen wird und main ist auch statisch.
	*	@return int[] mit min/max Werten auf x/y Achse
	*	@param	char[] mit Zeichenkette aus Buchstaben LRF (left, right, forward)
	*/
   private static int[] calculateScale(char[] kette){

	int[] scale = new int[4];	// array anthält die min/max positionen der Zeichnung bei den x und y-Achsen
	int y2 = 0, x2 =0;			// nur ein punkt nötig da nichts gezeichnet wird, sondern nur auf min/max werte überprüft
	String[] richtung = {"oben", "rechts", "unten", "links"};	// zur veranschaulichkeit die richtungen als Strings
	int pos = 1;												// die Zeichnung startet mit Richtung nach rechts
	for(int i = 0; i< kette.length; i++){						// die Schleife gleich wie oben nur ohne Zeichnung der Linie

		if(kette[i] == 'R'){

		pos = pos == 3 ? 0 : pos + 1;

	} else if(kette[i] == 'L'){

	    	pos = pos == 0 ? 3 : pos -1;

	}else{ // F

		if(richtung[pos].equals("oben")){

		    y2++;

		} else if (richtung[pos].equals("rechts")){

		    x2++;

		} else if (richtung[pos].equals("unten")){

		    y2--;

		} else {

		    x2--;

		}
	}


		if( x2 < scale[0]) // hier wird auf minimale Wert auf der x-Achse geprüft
		   scale[0] = x2;	// wenn es sich um bisher minimale Wert handelt, wird es in dem Array gespeichert
		if( x2 > scale[1])	// max bei x-Achse
		   scale[1] = x2;
		if( y2 < scale[2])	// min bei y-Achse
		   scale[2] = y2;
		if( y2 > scale[3])	// max bei y-Achse
		   scale[3] = y2;
	}
	return scale;			// array mit min/max x/y positionen wird zurückgeliefert
   }
}
